# Orbbec Astra 2 → Cloudflare R2 point-cloud snapshots

```
Astra 2 ──USB──> snapshotter.py (Windows PC) ──upload──> R2 bucket ──read──> viewer (GitHub Pages)
```

Every 15 minutes (on the quarter hour) the PC captures a depth snapshot (the median of 10 frames,
so it's cleaner than a single frame), uploads it to R2 and thins out old ones:

| Age              | Kept                 |
|------------------|----------------------|
| under 1 day      | every snapshot       |
| 1 day – 1 week   | one per hour         |
| 1 week – 1 month | one per day          |
| over 1 month     | one per week         |

"Hour", "day" and "week" follow the PC's local clock; the first snapshot in each
period is the one kept. The bucket levels off at about 265 snapshots (96 from the last day, 144 hourly,
about 23 daily), plus one per week after that.

## 1. Set up the R2 bucket (Cloudflare dashboard)
1. **R2 › Create bucket**, e.g. `astra-snapshots`.
2. **Bucket › Settings › Public access**: enable the r2.dev URL (or connect a custom
   domain). Copy the public URL, e.g. `https://pub-xxxx.r2.dev`.
   Anyone with this URL can view the snapshots.
3. **Bucket › Settings › CORS policy**: paste `r2-cors.json`, with your GitHub
   Pages address in `AllowedOrigins`.
4. **R2 › Manage API tokens › Create API token**: permission *Object Read & Write*,
   limited to this bucket. Note the Access Key ID, Secret Access Key and your
   Account ID.

## 2. Run the snapshotter on the Windows PC
1. Install 64-bit Python 3.10–3.12 from python.org (tick "Add python.exe to PATH").
2. In the `bridge` folder:
   ```
   pip install -r requirements.txt
   pip install pyorbbecsdk2
   ```
   If pip can't find pyorbbecsdk2 for your Python version, install the Windows
   `.whl` from github.com/orbbec/pyorbbecsdk/releases with `pip install <file>.whl`.
3. Plug the Astra 2 into a USB 3 port. Close Orbbec Viewer — only one program can
   use the camera at a time.
4. Edit `run_snapshots.bat`: fill in the four R2 values. Double-click it. Each snapshot prints one line.

Test without the camera first: `python snapshotter.py --mock --once`.
Test without R2: `python snapshotter.py --mock --local test-bucket --once`.

**Keep it running after restarts:** Task Scheduler › Create Task › Triggers: *At log on*
› Actions: start `run_snapshots.bat` › Conditions: untick "Start only if on AC power".
In Power settings set *Sleep* to *Never*, or the PC will stop taking snapshots.

Options: `--frames 10` (frames per snapshot), `--step 2` (quarter-size files),
`--width 800 --height 600` (pick a depth mode).

## 3. Host the viewer on GitHub Pages
1. Push this folder to a GitHub repo.
2. Settings › Pages › Deploy from a branch › `main`, folder `/docs`.
3. Open the page, paste the bucket's public URL, press Load.
   Shareable link: `https://<you>.github.io/<repo>/?bucket=https://pub-xxxx.r2.dev`

Drag the timeline, use ← → keys, or press Play for a time-lapse. The viewer checks
for new snapshots every minute.

## Cost
R2's free tier is 10 GB storage, 1 million writes and 10 million reads a month,
with free downloads. At 15-minute captures this uses about 6,000 writes a month
and roughly 100 MB of storage, so it should stay free. Deletes are free.

## Files in the bucket
- `index.json` — list of snapshots (key, time, size), rewritten after every capture
- `snapshots/YYYY/MM/DD/YYYYMMDDTHHMMSSZ.odp` — one depth frame each: 32-byte header
  (`ODP1`, width, height, fx, fy, cx, cy, mm per unit, flags) + zlib-compressed uint16 depth
